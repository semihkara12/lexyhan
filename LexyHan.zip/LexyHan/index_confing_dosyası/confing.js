module.exports = {
        token: "discord developer den alın", 
            prefix: "prefix!",
                botdavet: "discord developer portaldan alın",
                    desteksunucusu: "destek sunucu linki",
                        website: "https:// ile başlıyan ve .com ile biten rasgele bir şey",
                            topgg: "topgg den alın",
                                politika: "https:// ile başlıyan ve .com ile viten rasgele bir şey",
                                    sunucuid: "https:// ile başlıyan ve .com ile biten rasgele bir şey",
                                        destekçi: "https:// ile basliyan ve .com ile biten rasgele bir şey"
                                        };