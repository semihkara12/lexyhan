const { EmbedBuilder } = require("discord.js")
const diskord = require("discord.js")
const debe = require("croxydb")
const config = require("../config.js")
exports.run = async (client, message, args) => {
    const topgg = config.topgg
    const davet = config.botdavet
    const destek = config.desteksunucusu
    const value = args[0]

  const embed = new diskord.EmbedBuilder()
  .setTitle("Kategoriler")
  .setDescription(`**prefix!yardım ayarlamalı |** Ayarlamalı yetkili komutlarını gösterir.\n\n**prefix!yardım eğlence |** Eğlence Komutlarını Gösterir.\n\n**prefix!yardım kullanıcı |** Kullanıcı Komutlarını Gösterir.\n\n**prefix!yardım yetkili |** Yetkili Komutlarını Gösterir.\n\n**prefix!yardım bot |** Bot Komutlarını Gösterir\n🛎 **Botadi Bağlantılar** \n[Botu Sunucuna Ekle](${davet})\n[Destek Sunucum](${destek})\n[Bota Oy Ver](${topgg})`)
  if(!args[0]) return message.channel.send({embeds: [embed]})
if(value === "bot") {
const embed = new diskord.EmbedBuilder()
.setTitle("Ana Komutlar")
.setDescription("**prefix!istatistik |** Botun istatistiklerini gösterir\n**prefix!linkler |** Botla Alakalı Linkleri Alırsınız\n**prefix!oyver |** Botun oy verme linkini ve birkaç bilgi alırsınız\n**prefix!ping |** Botun pingini gösterir")
message.channel.send({embeds: [embed]})
}
if(value === "yetkili") {
const embed = new diskord.EmbedBuilder()
.setTitle("Yetkili Komutları")
.setDescription("**prefix!ban | ** Etiketlediğiniz kişiyi sunucudan yasaklar\n**prefix!ban-list |** Sunucundan Banlanan üyeleri gösterir\n**prefix!forceban |** ID'sini belirttiğiniz kullanıcıyı sunucudan yasaklar\n**prefix!kanal-açıklama |** Bulunduğunuz kanalın konusunu/açıklamasını değiştirir\n**prefix!kick |** İstediğiniz kişiyi sunucudan atar\n**prefix!rol-al** | Belirtilen kullanıcıdan istediğiniz rolü alır\n**prefix!rol-oluştur** | Yazılan Adda Rol Oluşturulur\n**prefix!rol-ver** | Belirtilen kullanıcıya istediğiniz rolü verir")
message.channel.send({embeds: [embed]})
const embed2 = new diskord.EmbedBuilder()
.setDescription("**prefix!sesli-çek |** Etiketlediğiniz kullanıcıyı yanınıza çeker\n**prefix!temizle |** Belirtilen miktar mesajı siler\n**prefix!unban |** Belirtilen kişinin banını kaldırır\n**prefix!slowmode** | Kanalda yavaşmod'u ayarlarsınız")
message.channel.send({embeds: [embed2]})
}
if(value === "eğlence") {
const embed = new diskord.EmbedBuilder()
.setTitle("Eğlence Komutları")
.setDescription("**prefix!alkış |** Bot Alkışlar\n**prefix!aşkölçer |** Bot etiketlediğiniz kişiye karşı olan aşkını ölçer\n**prefix!emojiyazı |** Bot mesajınızı emoji haline getirir\n**prefix!hackle |** Etiketlediğiniz kişiyi hackler\n**prefix!kaçcm |** Malafatının uzunluğunu söyler")
message.channel.send({embeds: [embed]})
const embed2 = new diskord.EmbedBuilder()
.setDescription("**prefix!sarıl |** Etiketlediğiniz kişiye sarılırsınız\n**prefix!slot |** Slots oyununu oynar\n**prefix!şanslısayım |** Bot Şanslı sayınızı tahmin eder\n**prefix!zencigot** | twerk atan zencigot")
message.channel.send({embeds: [embed2]})
}
if(value === "kullanıcı") {
const embed = new diskord.EmbedBuilder()
.setTitle("Kullanıcı Komutları")
.setDescription("**prefix!afk |** AFK olunca seni etiketleyen kişiye sebebini yazar\n**prefix!atatürk |** Rastgele bir Atatürk fotoğrafı gönderir\n**prefix!avatar |** Etiketlediğiniz kişinin avatarını gösterir\n**prefix!emojiler |** Sunucuda bulunan emojileri gösterir\n**prefix!hesapla |** Belirtilen işlemi yapar\n**prefix!kurucu-kim |** Sunucunun kurucusunu söyler")
message.channel.send({embeds: [embed]})
const embed2 = new diskord.EmbedBuilder()
.setDescription("**prefix!minecraft |** Belirlediğiniz Minecraft sunucusunun bilgilerini verir\n**prefix!not-al |** Bot not alır\n**prefix!notum |** Notunuzu gösterir\n**prefix!radyo |**  Sesli kanaldan Radyo dinlersiniz\n**prefix!sunucubilgi |** Bulunduğun sunucu hakkında bilgi verir")
message.channel.send({embeds: [embed2]})
}
if(value === "ayarlamalı") {
const embed = new diskord.EmbedBuilder()
.setTitle("Ayarlamalı Komutları")
.setDescription("**prefix!küfürengel |** Küfür engelleme sistemini ayarlamanızı sağlar\n**prefix!reklamengel |** Reklam engelleme sistemini ayarlamanızı sağlar\n**prefix!oto-cevap |** Belirtilen yazıyı biri yazarsa bot belirtilen cevabı vermeye ayarlanır\n**prefix!otorol |** Sunucuya girenlere verilecek olan otorolü ayarlar\n**prefix!ototag |** Bot belirtilen tagı sunucuya girenlerin isimlerinin başına koyar\n**prefix!sa-as |** Oto sa-ası ayarlarsınız\n**prefix!sayaç |** Sayacı ayarlarsınız")
message.channel.send({embeds: [embed]})
}
}

exports.conf = {
  aliases: []
}

exports.help = {
  name: "yardım"
}