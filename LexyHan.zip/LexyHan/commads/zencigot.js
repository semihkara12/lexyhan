const { EmbedBuilder } = require("discord.js")
const diskord = require("discord.js")
const debe = require("croxydb")
exports.run = async (client, message, args) => {
    
       
       const embed = new EmbedBuilder()
       .setImage("https://media4.giphy.com/media/Kx4bjH5bDSKyWtavq5/giphy.gif")

       message.channel.send({embeds: [embed]})

       }



       exports.conf = {
         aliases: []
         }

         exports.help = {
           name: "zencigot"
           };