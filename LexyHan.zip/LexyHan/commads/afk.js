const {EmbedBuilder} = require("discord.js");
const Discord = require("discord.js")
const db = require("croxydb")
exports.run = async (client, message, args) => {
    var kullanici = message.author;
    var sebep = args.slice(0).join("  ");
    
      if (!sebep) return message.channel.send("lüften bir sebep gir"
      );
      const row = new Discord.ActionRowBuilder()
      .addComponents(
new Discord.ButtonBuilder()
.setLabel("afk kalicagina eminmisin?")
.setStyle(Discord.ButtonStyle.Success)
.setCustomId("evet eminim")

      )
message.reply({content: "emin misin?", components: [row]}).then(msg => {
    msg.createMessageComponentCollector(user => user.clicker.user.id == message.author.id).on('collect', async (button) => {
      let interaction = button
        if (interaction.customId == "evet") {
    msg.delete()
        message.channel.send("basarili")
        
      db.set(`afk_${kullanici.id}`, sebep);
        }
    })
})
}
exports.conf = {
  aliases: []
};
exports.help = {
  name: "afk"  
};